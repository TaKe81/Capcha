﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace UnitTestProject1
{
    [TestClass]
    public class CaptchaTest
    {
        [TestMethod]
        public void GetCaptchaStrength_AllChars()
        {
            string captcha = "As%@1g";
            int expected = 1;
            int actual = CaptchaLibrary.CaptchaClass.GetCaptchaLength(captcha);
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void GetCaptchaLowerCase_AllChars()
        {
            string captcha = "As%@1g";
            int expected = 1;
            int actual = CaptchaLibrary.CaptchaClass.GetCaptchaLowerCase(captcha);
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void GetCaptchaUpperCase_AllChars()
        {
            string captcha = "As%@1g";
            int expected = 1;
            int actual = CaptchaLibrary.CaptchaClass.GetCaptchaUpperCase(captcha);
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void GetCaptchaNumbers_AllChars_()
        {
            string captcha = "As%@1g";
            int expected = 1;
            int actual = CaptchaLibrary.CaptchaClass.GetCaptchaNumbers(captcha);
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void GetCaptchaSpecial_AllChars_()
        {
            string captcha = "As%@1g";
            int expected = 1;
            int actual = CaptchaLibrary.CaptchaClass.GetCaptchaSpecial(captcha);
            Assert.AreEqual(expected, actual);
        }
    }
}
