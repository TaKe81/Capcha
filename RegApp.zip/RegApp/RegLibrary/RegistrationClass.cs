﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace RegLibrary
{
    public class RegistrationClass
    {
        public static string emailPattern = @"^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$";
        public static string passwordPattern = @"^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{1,50}$";

        /// <summary>
        /// Проверка правильности ввода Email
        /// </summary>
        /// <param name="origEmail"></param>
        /// <param name="emailPattern"></param>
        /// <returns></returns>
        public static bool isItEmail(string origEmail, string emailPattern)
        {
            bool result = false;
            result = Regex.IsMatch(origEmail, emailPattern);

            return result;
        }

        /// <summary>
        /// Проверка правильности ввода пароля
        /// </summary>
        /// <param name="origPassword"></param>
        /// <param name="passwordPattern"></param>
        /// <returns></returns>
        public static bool isItPassword(string origPassword, string passwordPattern)
        {
            bool result = false;
            result = Regex.IsMatch(origPassword, passwordPattern);

            return result;
        }
        
    }
}
